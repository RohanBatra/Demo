export declare class ProgressBar {
    value: any;
    showValue: boolean;
    style: object;
    styleClass: string;
    unit: string;
    mode: string;
}
export declare class ProgressBarModule {
}
