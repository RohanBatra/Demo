"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var UIMessage = (function () {
    function UIMessage() {
    }
    Object.defineProperty(UIMessage.prototype, "icon", {
        get: function () {
            var icon = null;
            if (this.severity) {
                switch (this.severity) {
                    case 'success':
                        icon = 'fa fa-check';
                        break;
                    case 'info':
                        icon = 'fa fa-info-circle';
                        break;
                    case 'error':
                        icon = 'fa fa-close';
                        break;
                    case 'warn':
                        icon = 'fa fa-warning';
                        break;
                    case 'success':
                        icon = 'fa fa-check';
                        break;
                    default:
                        icon = 'fa fa-info-circle';
                        break;
                }
            }
            return icon;
        },
        enumerable: true,
        configurable: true
    });
    return UIMessage;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], UIMessage.prototype, "severity", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], UIMessage.prototype, "text", void 0);
UIMessage = __decorate([
    core_1.Component({
        selector: 'p-message',
        template: "\n        <div aria-live=\"polite\" class=\"ui-message ui-widget ui-corner-all\" *ngIf=\"severity\"\n        [ngClass]=\"{'ui-messages-info': (severity === 'info'),\n                'ui-messages-warn': (severity === 'warn'),\n                'ui-messages-error': (severity === 'error'),\n                'ui-messages-success': (severity === 'success')}\">\n            <span class=\"ui-message-icon\" [ngClass]=\"icon\"></span>\n            <span class=\"ui-message-text\">{{text}}</span>\n        </div>\n    "
    })
], UIMessage);
exports.UIMessage = UIMessage;
var MessageModule = (function () {
    function MessageModule() {
    }
    return MessageModule;
}());
MessageModule = __decorate([
    core_1.NgModule({
        imports: [common_1.CommonModule],
        exports: [UIMessage],
        declarations: [UIMessage]
    })
], MessageModule);
exports.MessageModule = MessageModule;
//# sourceMappingURL=message.js.map